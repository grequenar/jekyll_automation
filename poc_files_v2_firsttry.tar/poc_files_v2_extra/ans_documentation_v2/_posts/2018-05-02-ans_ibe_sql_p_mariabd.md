--- 
layout: post 
title: mariadb role 
permalink: /ans/ibe/sql/p/ans_ibe_sql_p_mariabd.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_ibe_sql_p_mariabd][ans_ibe_sql_p_mariabd] 
 
[ans_ibe_sql_p_mariabd]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
