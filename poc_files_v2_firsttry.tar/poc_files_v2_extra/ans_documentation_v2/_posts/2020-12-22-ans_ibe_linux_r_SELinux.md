--- 
layout: post 
title: SELinux role 
permalink: /ans/ibe/linux/r/ans_ibe_linux_r_SELinux.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_ibe_linux_r_SELinux][ans_ibe_linux_r_SELinux] 
 
[ans_ibe_linux_r_SELinux]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role to manage SELinux policy modules 
 
## Date 
 
2020-12-22

## Tags

RHEL
