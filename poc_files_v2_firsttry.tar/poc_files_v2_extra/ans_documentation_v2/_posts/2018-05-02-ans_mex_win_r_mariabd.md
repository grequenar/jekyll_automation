--- 
layout: post 
title: mariadb windows role 
permalink: /ans/mex/win/r/ans_mex_win_r_mariabd.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_mex_win_r_mariabd][ans_mex_win_r_mariabd] 
 
[ans_mex_win_r_mariabd]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
