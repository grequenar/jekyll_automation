--- 
layout: post 
title: mariadb role playbook 
permalink: /ans/ibe/linux/p/ans_ibe_linux_p_mariabd.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_ibe_linux_p_mariabd][ans_ibe_linux_p_mariabd] 
 
[ans_ibe_linux_p_mariabd]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
