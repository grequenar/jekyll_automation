--- 
layout: post 
title: selinux role avangrid 
permalink: /ans/agr/linux/p/ans_agr_linux_p_SELinux.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_agr_linux_p_SELinux][ans_agr_linux_p_SELinux] 
 
[ans_agr_linux_p_SELinux]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
