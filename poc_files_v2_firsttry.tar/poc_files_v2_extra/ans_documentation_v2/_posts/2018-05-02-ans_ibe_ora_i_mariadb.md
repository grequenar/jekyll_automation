--- 
layout: post 
title: mariadb role inventory 
permalink: /ans/ibe/ora/i/ans_ibe_ora_i_mariadb.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_ibe_ora_i_mariadb][ans_ibe_ora_i_mariadb] 
 
[ans_ibe_ora_i_mariadb]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
