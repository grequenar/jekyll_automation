--- 
layout: post 
title: mariadb role brasil 
permalink: /ans/mex/linux/c/ans_mex_linux_c_mariabd.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_mex_linux_c_mariabd][ans_mex_linux_c_mariabd] 
 
[ans_mex_linux_c_mariabd]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role for mariadb iberdrola for linux machines 
 
## Date 
 
2018-05-02

## Tags

RHEL
