--- 
layout: post 
title: NTP role windows 
permalink: /ans/ibe/win/r/ans_ibe_win_r_ntp.html 
--- 

## Author

Gloria

## Repo URL 
 
 [ans_ibe_win_r_ntp][ans_ibe_win_r_ntp] 
 
[ans_ibe_win_r_ntp]: https://github.com/tvallas/ansible-role-selinux 
 
## Description 
 
Ansible role to manage SELinux policy modules 
 
## Date 
 
2020-12-11

## Tags

RHEL
